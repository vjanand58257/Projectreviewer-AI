def hello():
    print("Hello")
